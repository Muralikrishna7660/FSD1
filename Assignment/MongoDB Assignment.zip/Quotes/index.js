import express from "express" 
import bodyParser from "body-parser"
import quoteRouter from "./route/quotes.js"
import mongoose from 'mongoose'

const dbURI='mongodb+srv://Murali1:Murali1@cluster0.oailz.mongodb.net/Quotes?retryWrites=true&w=majority'
mongoose.connect(dbURI,{useNewUrlParser:true, useUnifiedTopology:true})
    .then(
        (result) => {
            console.log("Connected to the DB")
            server.listen(PORT)
            console.log("Server started")
        }
    )
    .catch(
        (err)=>{
            console.log(err)
        }
    )

const server=express()
const PORT=4000
server.use(bodyParser.json())


var homepage=(req,res)=> res.send("Welcome to my Quotes")
server.use("/quote",quoteRouter)
server.get("/",homepage)