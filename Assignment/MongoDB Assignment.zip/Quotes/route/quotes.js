import express from 'express';
import {getQuotes,createQuotes} from '../controllers/quotes.js'

const router=express.Router();

router.get("/getall",getQuotes)
router.post("/add",createQuotes)

export default router 