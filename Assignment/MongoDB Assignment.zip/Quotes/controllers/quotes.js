import {Quote} from '../model/quotes.js'

let quote=[] 

export const createQuotes = (req,res)=>{
    const quotes = new Quote({
        quote: req.body.quote,
        author: req.body.author,
    })
    quotes.save()
        .then(
            (result)=>{
                res.send({"result":"success"})
            }
        )
        .catch(
            (err)=>{
                console.log(err)
            }
        )
}

export const getQuotes= (req,res)=>{
    
        getAll(req,res)
}

const getAll = (req,res) => {
    Quote.aggregate([  
             { $project:{ _id :0,quote :1,author :1}}     
    ])
    .then(
        (result)=>{
            res.send(result)
            console.log(result)
        }
    )
    .catch(
        (err)=>{
            console.log(err)
        }
    )
}

