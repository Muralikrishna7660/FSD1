import {Product} from '../model/product.js'

let products=[] 

export const createProducts = (req,res)=>{
    const product = new Product({
        productname: req.body.productname,
        price: req.body.price,
    })
    product.save()
        .then(
            (result)=>{
                res.send({"status":"success"})
            }
        )
        .catch(
            (err)=>{
                console.log(err)
            }
        )
}

export const getAllProducts= (req,res)=>{
    
        getAll(req,res)
}

const getAll = (req,res) => {
    Product.aggregate([  
             { $project:{ _id :0,productname :1,price :1}}     
    ])
    .then(
        (result)=>{
            res.send(result)
            console.log(result)
        }
    )
    .catch(
        (err)=>{
            console.log(err)
        }
    )
}
