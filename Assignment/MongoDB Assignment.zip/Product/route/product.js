import express from 'express';
import {getAllProducts,createProducts} from '../controllers/product.js'

const router=express.Router();

router.get("/getall",getAllProducts)
router.post("/add",createProducts)

export default router 