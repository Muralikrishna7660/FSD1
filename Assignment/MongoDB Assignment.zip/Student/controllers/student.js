import {Student} from '../model/student.js'

let students=[] 

export const getStudents= (req,res)=>
{

    if(req.query.name)
    {
        getStudentbyName(req,res)

    }else{
        Student.find()
            .then(
                (result)=>
                {
                    res.send(result)
                }
            )
            .catch(
                (err)=>
                {
                    console.log(err)
                    
                }
            )
    }
}


export const createStudents = (req,res)=>
{
    const student = new Student(
        {
        name: req.body.name,
        collegename: req.body.collegename,
        location: req.body.location,
        }
    )
    student.save()
        .then(
            (result)=>{
                res.send({"result":"Success"})
            }
        )
        .catch(
            (err)=>{
                console.log(err)
            }
        )
}
const getStudentbyName = (req,res) => {
    
    Student.aggregate([  
           {$match:{"name":req.query.name}},
             { $project:{ _id :0,name :1,collegename :1,location :1}}     
    ])

    .then(
        (result)=>{
            res.send(result)
            console.log(result)
    
        }
    )
    .catch(
        (err)=>{
            console.log(err)
        }
    )
}
