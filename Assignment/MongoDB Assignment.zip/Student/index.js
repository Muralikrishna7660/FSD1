import express from "express"             //importing the express 
import bodyParser from "body-parser"      //importing body-parser
import studentRouter from "./route/student.js"   //importing the route folder
import mongoose from 'mongoose'            //importing mongoose database

const dbURI='mongodb+srv://Murali1:Murali1@cluster0.oailz.mongodb.net/Student?retryWrites=true&w=majority'  //Connecting to MongooseDB user and database
mongoose.connect(dbURI,{useNewUrlParser:true, useUnifiedTopology:true})  
    .then(
        (result) => {
            console.log("Connected to the DB")
            server.listen(PORT)
            console.log("Server started")
        }
    )
    .catch(
        (err)=>{
            console.log(err)
        }
    )

const server=express()        //creating express variable
const PORT=3000               //allocating port number
server.use(bodyParser.json())

var homepage=(req,res)=> res.send("Welcome to Student Details") //handling http://localhost:3000/
server.use("/student/getstudentdetails",studentRouter)          //Navigate to router folder
server.use("/student",studentRouter)                            //Navigate to router folder
server.get("/",homepage)                            //Navigate to student